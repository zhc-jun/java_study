# Contanct Me

如果觉得看起来比较麻烦，需要PDF版本，或是需要更多学习资料，都可以加上QQ群领取

>本群由我创立，目前已将群主权限交由合作方便于进行日常管理，介意的朋友们在GitHub上看最新版就好了
>
>> 这份笔记资料是会免费提供的，特地向你们保证…毕竟还是要恰饭的嘛…

祝愿每一位有追求的Java开发同胞都能进大厂拿高薪！

## QQ群

Java架构交流QQ群：**578486082** （备注一下GitHub，免得被认成打无良广告的）

快捷加群方式：[点击此处加入群聊：java高级程序猿①](https://jq.qq.com/?_wv=1027&k=oE5kCnMu)

![image.png](https://upload-images.jianshu.io/upload_images/24613101-931262091ba7ed2b.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

> PS：
>
> > 平常很忙，找miffy小姐姐领取就好了，免费获取的！

![image.png](https://upload-images.jianshu.io/upload_images/24613101-4b0507ab7ef34106.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

------



## 1\. 你说的NoSQL数据库是什么意思?NoSQL与RDBMS直接有什么区别?为什么要使用和不使用NoSQL数据库?说一说NoSQL数据库的几个优点?

NoSQL是非关系型数据库，NoSQL = Not Only SQL。

关系型数据库采用的结构化的数据，NoSQL采用的是键值对的方式存储数据。

在处理非结构化/半结构化的大数据时；在水平方向上进行扩展时；随时应对动态增加的数据项时可以优先考虑使用NoSQL数据库。

在考虑数据库的成熟度；支持；分析和商业智能；管理及专业性等问题时，应优先考虑关系型数据库。

## 2\. NoSQL数据库有哪些类型?



## 3\. MySQL与MongoDB之间最基本的差别是什么?



## 4\. 你怎么比较MongoDB、CouchDB及CouchBase?



## 5\. MongoDB成为最好NoSQL数据库的原因是什么?



## 6.32位系统上有什么细微差别?



## 7\. journal回放在条目(entry)不完整时(比如恰巧有一个中途故障了)会遇到问题吗?



## 8\. 分析器在MongoDB中的作用是什么?



## 9\. 名字空间(namespace)是什么?



## 10\. 如果用户移除对象的属性，该属性是否从存储层中删除?



## 11\. 能否使用日志特征进行安全备份?



## 12\. 允许空值null吗?



## 13\. 更新操作立刻fsync到磁盘?



## 14\. 如何执行事务/加锁?



## 15\. 为什么我的数据文件如此庞大?



## 16\. 启用备份故障恢复需要多久?



## 17\. 什么是master或primary?



## 18\. 什么是secondary或slave?



## 19\. 我必须调用getLastError来确保写操作生效了么?



## 20\. 我应该启动一个集群分片(sharded)还是一个非集群分片的 MongoDB 环境?



## 21\. 分片(sharding)和复制(replication)是怎样工作的?



## 22\. 数据在什么时候才会扩展到多个分片(shard)里?



## 23\. 当我试图更新一个正在被迁移的块(chunk)上的文档时会发生什么?



24\.  如果在一个分片(shard)停止或者很慢的时候，我发起一个查询会怎样?



## 25\. 我可以把moveChunk目录里的旧文件删除吗?



## 26\. 我怎么查看 Mongo 正在使用的链接?



## 27\. 如果块移动操作(moveChunk)失败了，我需要手动清除部分转移的文档吗?



## 28\. 如果我在使用复制技术(replication)，可以一部分使用日志(journaling)而其他部分则不使用吗?



## 29.当更新一个正在被迁移的块（Chunk）上的文档时会发生什么？



## 30.MongoDB在A:{B,C}上建立索引，查询A:{B,C}和A:{C,B}都会使用索引吗？



## 31.如果一个分片（Shard）停止或很慢的时候，发起一个查询会怎样？



## 32\. MongoDB支持存储过程吗？如果支持的话，怎么用？



## 33.如何理解MongoDB中的GridFS机制，MongoDB为何使用GridFS来存储文件？



