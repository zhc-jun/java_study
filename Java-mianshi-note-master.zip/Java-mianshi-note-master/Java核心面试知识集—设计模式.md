# Contanct Me

如果觉得看起来比较麻烦，需要PDF版本，或是需要更多学习资料，都可以加上QQ群领取

>本群由我创立，目前已将群主权限交由合作方便于进行日常管理，介意的朋友们在GitHub上看最新版就好了
>
>> 这份笔记资料是会免费提供的，特地向你们保证…毕竟还是要恰饭的嘛…

祝愿每一位有追求的Java开发同胞都能进大厂拿高薪！

## QQ群

Java架构交流QQ群：**578486082** （备注一下GitHub，免得被认成打无良广告的）

快捷加群方式：[点击此处加入群聊：java高级程序猿①](https://jq.qq.com/?_wv=1027&k=oE5kCnMu)

![image.png](https://upload-images.jianshu.io/upload_images/24613101-931262091ba7ed2b.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


>PS：
>
>>平常很忙，找miffy小姐姐领取就好了，免费获取的！

![image.png](https://upload-images.jianshu.io/upload_images/24613101-4b0507ab7ef34106.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

# 设计模式知识点笔记汇总

## 1.单例模式（Singleton Pattern）

## 2.工厂模式

## 3.抽象工厂模式（Abstract Factory Pattern）

## 4.模板方法模式（Template Method Pattern）

## 5.建造者模式（Builder Pattern）

## 6.代理模式（Proxy Pattern）

## 7.原型模式（Prototype Pattern）

## 8.中介者模式

## 9.命令模式

## 10.责任链模式

## 11.装饰模式（Decorator Pattern）

## 12.策略模式（Strategy Pattern）

## 13.适配器模式（Adapter Pattern）

这一块后面会更新的，有已经整理的解析在这份【Java核心面试知识集】知识点笔记文档里了，**有需要的朋友可以加交流Q群：578486082 管理员处免费领取！**

![](https://upload-images.jianshu.io/upload_images/11474088-a6f003ad297d6e6d.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

